const colors = require("tailwindcss/colors");

module.exports = {
  purge: ["./**/*.html", "./**/*.js"],
  darkMode: false,
  theme: {
    extend: {},
    colors: {
      // Your existing colors...
      transparent: "transparent",
      current: "currentColor",
      black: "#000",
      white: "#fff",
      bluegray: colors.blueGray,
      coolgray: colors.coolGray,
      gray: colors.gray,
      truegray: colors.trueGray,
      warmgray: colors.warmGray,
      orange: colors.orange,
      amber: colors.amber,
      yellow: colors.yellow,
      lime: colors.lime,
      green: colors.green,
      emerald: colors.emerald,
      teal: colors.teal,
      cyan: colors.cyan,
      sky: colors.sky,
      blue: colors.blue,
      indigo: colors.indigo,
      violet: colors.violet,
      purple: colors.purple,
      fuchsia: colors.fuchsia,
      pink: colors.pink,
      rose: colors.rose,
      'red-950': '#FF0000', // Define your custom color here
      // Add your custom dark green color here
      'dark-green': '#006400', // You can change the hex code to your desired dark green color
      'gull-gray': {
        DEFAULT: '#95A6B7',
        50: '#F4F6F8',
        100: '#E7EBEE',
        200: '#CBD4DC',
        300: '#B0BDC9',
        400: '#95A6B7',
        500: '#738AA0',
        600: '#596E82',
        700: '#425261',
        800: '#2B3640',
        900: '#15191E',
        950: '#090B0E',
      },
    },
    extend: {
      backgroundColor: {
        'dark-green': '#006400', // You can change the hex code to your desired dark green color
      },
    },
  },
  variants: {},
  plugins: [],
};
