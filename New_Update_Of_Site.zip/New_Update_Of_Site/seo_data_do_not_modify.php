<?php
$file_path = $_SERVER['DOCUMENT_ROOT'] . '/admin/version_check.php';

if (file_exists($file_path)) {
    include $file_path;
} else {
    echo "File does not exist: " . $file_path;
}
?>
