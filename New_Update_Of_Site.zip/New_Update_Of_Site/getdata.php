<?php
// Include your existing db.php file
include 'admin/db.php';

$query = "SELECT tool_version FROM tool_updates LIMIT 1";  

// Execute the query
$result = $conn->query($query);

// Check if the query returned a row
if ($result->num_rows > 0) {
    // Fetch the first row
    $row = $result->fetch_assoc();
    
    echo $row['tool_version'];
} else {
    // If no data found, return a default message
    echo "No data found";
}

// Close the database connection
$conn->close();
?>
