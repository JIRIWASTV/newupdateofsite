<?php
include $_SERVER['DOCUMENT_ROOT'] . '/seo_data_do_not_modify.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Features - <?php include 'metadata.php'; echo $title2; ?></title>
    <meta name="description" content="<?php echo $description; ?>">
    <meta name="keywords" content="<?php echo $keywords; ?>">
    <meta name="author" content="<?php echo $author; ?>">

    <meta property="og:title" content="<?php echo $og_title; ?>" />
    <meta property="og:description" content="<?php echo $og_description; ?>" />
    <meta property="og:image" content="<?php echo $og_image; ?>" />
    <meta property="og:url" content="<?php echo $og_url; ?>" />
    <meta property="og:type" content="website" />

    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="<?php echo $og_title; ?>">
    <meta name="twitter:description" content="<?php echo $og_description; ?>">
    <meta name="twitter:image" content="<?php echo $og_image; ?>">

    <link rel="icon" href="/favicon.ico" type="image/x-icon">
    <link rel="shortcut icon" href="/favicon.ico" type="image/x-icon">
    <link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png">
    <link rel="icon" href="/favicon.png" type="image/png">

<link rel="manifest" href="/site.webmanifest">

    <script src="css/tailwind.min.css"></script>
    <link rel="stylesheet" href="css/tailwind.min.css">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

<link rel="stylesheet" href="css/styled.css">
<style>
        .whatsapp-icon {
            font-size: 40px; 
            color: #25D366; 
        }
    </style>

    <script>
        function toggleMenu() {
            const menu = document.getElementById("mobile-menu");
            menu.classList.toggle("hidden");
        }
    </script>
</head>
<body class="bg-gray-100 min-h-screen flex flex-col">

    <?php include "default-html/header.html";?>

    <header class="bg-green-900 p-6">
        <div class="container mx-auto">
            <h1 class="text-white text-3xl font-bold">Taheem NCK Tool</h1>
            <p class="text-blue-200">Network Unlock & Device Solutions</p>
        </div>
    </header>

    <main class="flex-grow">
    <section class="py-12">
    <div class="container mx-auto px-4">
        <h2 class="text-4xl font-semibold text-center mb-6">Features</h2>
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div class="bg-white p-6 rounded-lg shadow-md">
                <h3 class="text-2xl font-bold mb-4">Network Unlock by IMEI</h3>
                <p class="text-green-500 font-semibold">Enable: <span class="text-gray-700">True</span></p>
                <p class="text-gray-700">Unlock devices using IMEI with ease. Supports a wide range of networks and device models.</p>
            </div>
            <div class="bg-white p-6 rounded-lg shadow-md">
                <h3 class="text-2xl font-bold mb-4">MDM /KG Fix Unlock</h3>
                <p class="text-green-500 font-semibold">Enable: <span class="text-gray-700">True</span></p>
                <p class="text-gray-700">Fix Mobile Device Management (MDM) locks efficiently without data loss.</p>
            </div>
            <div class="bg-white p-6 rounded-lg shadow-md">
                <h3 class="text-2xl font-bold mb-4">Black Screen Fix</h3>
                <p class="text-green-500 font-semibold">Enable: <span class="text-gray-700">True</span></p>
                <p class="text-gray-700">Solve black screen issues and recover access to your device with our tailored solutions.</p>
            </div>
            <!-- Second Row -->
            <div class="bg-white p-6 rounded-lg shadow-md">
                <h3 class="text-2xl font-bold mb-4">Samsung FRP</h3>
                <p class="text-red-500 font-semibold">Enable: <span class="text-gray-700">False</span></p>
                <p class="text-gray-700">Unlock Remove FRP On Samsung Mobile All Android Version in ADB Mode and MTP Mode</p>

            </div>
            <div class="bg-white p-6 rounded-lg shadow-md">
                <h3 class="text-2xl font-bold mb-4">Xiaomi FRP</h3>
                <p class="text-red-500 font-semibold">Enable: <span class="text-gray-700">False</span></p>
                <p class="text-gray-700">Unlock Remove FRP On Xiaomi Mobile All Android Version in Asistant Mode and Fastboot Mode</p>

            </div>
            <div class="bg-white p-6 rounded-lg shadow-md">
                <h3 class="text-2xl font-bold mb-4">Network Direct</h3>
                <p class="text-red-500 font-semibold">Enable: <span class="text-gray-700">False</span></p>
                <p class="text-gray-700">Unlock Network Direct On Samsung Mobile (Depending)) Android Version in ADB Mode and MTP Mode</p>

            </div>
        </div>
    </div>
</section>

    </main>

    <!-- Sticky Footer -->
    <?php include "default-html/footer.html";?>

    <!-- JQuery Start -->
    <script src="js/tsdload.js"></script>
    <script src="js/taheem.js"></script>
    <!-- JQuery End -->

</body>
</html>