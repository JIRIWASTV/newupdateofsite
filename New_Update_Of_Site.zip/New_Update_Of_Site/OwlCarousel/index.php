<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Redirecting...</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <meta http-equiv="refresh" content="0; url=/">
    <style>
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-color: #f9fafb; /* Tailwind's gray-100 */
        }
    </style>
</head>
<body>
    <div class="text-center">
        <h1 class="text-2xl font-bold mb-4">Redirecting...</h1>
        <p class="text-gray-600">If you are not redirected, <a href="/" class="text-blue-500 underline">click here</a>.</p>
    </div>
</body>
</html>
