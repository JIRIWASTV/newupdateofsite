<?php
// Database connection
include 'db.php';
session_start();

include $_SERVER['DOCUMENT_ROOT'] . '/seo_data_do_not_modify.php';


$error_message = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $login_input = $_POST['login_input'];
    $password = $_POST['password'];

    // Update the query to include Role = 1 and IsActive = 'Active'
    $stmt = $conn->prepare("SELECT id, username, password, role, IsActive, credits FROM admin_logs WHERE (email = ? OR username = ?) AND role = 1 AND IsActive = 'Active'");
    $stmt->bind_param("ss", $login_input, $login_input);
    $stmt->execute();
    $stmt->store_result();
    $stmt->bind_result($id, $username, $hashed_password, $role, $isActive, $credits);
    $stmt->fetch();

    if ($stmt->num_rows > 0 && password_verify($password, $hashed_password)) {
        if ($isActive == "Active") {
            $_SESSION['admin_id'] = $id;
            $_SESSION['admin_username'] = $username;
            $_SESSION['admin_role'] = $role;
            $_SESSION['admin_credits'] = $credits;

            // Update last_seen on successful login
            $last_seen = date("Y-m-d H:i:s");
            $stmt_update = $conn->prepare("UPDATE admin_logs SET last_seen = ? WHERE id = ?");
            $stmt_update->bind_param("si", $last_seen, $id);
            $stmt_update->execute();

            header("Location: dashboard.php");
        } else {
            $error_message = "Account is inactive.";
        }
    } else {
        $error_message = "Invalid credentials or you don't have admin access.";
    }

    $stmt->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <style>
        body {
            display: flex;
            flex-direction: column;
            min-height: 100vh; /* Ensures full height of the viewport */
            margin: 0; /* Remove default margin */
        }
        .content {
            flex: 1; /* Allow the content to grow and take available space */
            display: flex;
            flex-direction: column;
            justify-content: center; /* Centers content vertically */
            align-items: center; /* Centers content horizontally */
            padding: 1.5rem; /* Use padding for spacing */
        }
        .form-container {
            width: 100%; /* Full width */
            max-width: 400px; /* Limit max width for larger screens */
            background: white;
            padding: 1.5rem; /* Use padding for spacing */
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            border-radius: 0.5rem; /* Rounded corners */
        }
    </style>
</head>
<body class="bg-gray-400">

   
    <div class="content">
    <h1 class="text-2xl md:text-3xl font-bold mb-6 text-center">Admin | Taheem NCK Tool</h1>

        <div class="form-container">
            <h2 class="text-xl md:text-2xl font-bold mb-6 text-center">Admin Login</h2>

            <?php if (!empty($error_message)): ?>
            <div class="bg-red-500 text-white p-2 rounded mb-4 text-center">
                <?php echo $error_message; ?>
            </div>
            <?php endif; ?>

            <form action="index.php" method="POST">
                <div class="mb-4">
                    <label for="login_input" class="block text-gray-700">Username or Email</label>
                    <input type="text" name="login_input" class="w-full p-2 border border-gray-300 rounded mt-1" required>
                </div>
                <div class="mb-4">
                    <label for="password" class="block text-gray-700">Password</label>
                    <input type="password" name="password" class="w-full p-2 border border-gray-300 rounded mt-1" required>
                </div>
                <button type="submit" class="w-full bg-blue-500 text-white py-2 rounded mt-4 hover:bg-blue-600">Login</button>
            </form>
        </div>
    </div>

    <!-- Sticky Footer -->
    <footer class="bg-gray-900 text-white py-6">
        <div class="container mx-auto px-6 flex justify-between items-center">
            <p class="text-white font-bold">Taheem NCK Tool ( Version 1.0.0 )</p>
            <p class="text-white">&copy; 2024 TaheemSoftware</p>
        </div>
    </footer>

    <!-- JQuery Start -->
    <script src="js/tsdload.js"></script>
    <script src="js/taheem.js"></script>
    <!-- JQuery End -->

</body>
</html>
