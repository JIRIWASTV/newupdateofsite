<?php
// version_check.php

// Function to check if the PHP version is allowed
function isPhpVersionAllowed() {
    return version_compare(PHP_VERSION, '8.0.0', '>=');
}

// Check if the PHP version is allowed
if (!isPhpVersionAllowed()) {
    // If the version is lower than 8.0.0, display an error message
    header('HTTP/1.1 500 Internal Server Error');
    echo "This script requires PHP version 8.0.0 or higher.";
    exit();
}

// If the PHP version is valid (8.0.0 or higher), you can proceed with your code.
// Optional: Log the version check for security audits
file_put_contents('version_check.log', "PHP version: " . PHP_VERSION . " - Allowed\n", FILE_APPEND);

// Your PHP code continues here
?>