<?php
// Database connection
include 'db.php';
session_start();

include $_SERVER['DOCUMENT_ROOT'] . '/seo_data_do_not_modify.php';

$success_message = '';
$error_message = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);
    $role = 1; // Set role to 1
    $isActive = 'Active'; // Set account status to 'Active'
    $addeddate = date("Y-m-d H:i:s");
    $credits = 10;  // Default credits
    $last_seen = null;

    // Check if username or email already exists
    $check_stmt = $conn->prepare("SELECT id FROM admin_logs WHERE username = ? OR email = ?");
    $check_stmt->bind_param("ss", $username, $email);
    $check_stmt->execute();
    $check_stmt->store_result();

    if ($check_stmt->num_rows > 0) {
        $error_message = "Username or email already exists.";
    } else {
        // Prepare insert statement
        $stmt = $conn->prepare("INSERT INTO admin_logs (username, email, password, role, IsActive, addeddate, last_seen, credits) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssssii", $username, $email, $password, $role, $isActive, $addeddate, $last_seen, $credits);

        if ($stmt->execute()) {
            $success_message = "Admin Registered Successfully";
        } else {
            $error_message = "Error: " . $stmt->error;
        }
        $stmt->close();
    }
    $check_stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Register</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100 flex justify-center items-center min-h-screen">
    <div class="w-full max-w-md bg-white p-8 shadow-lg rounded-lg">
        <h2 class="text-2xl font-bold mb-6 text-center">Admin Registration</h2>

        <?php if (!empty($success_message)): ?>
        <div class="bg-green-500 text-white p-2 rounded mb-4 text-center">
            <?php echo $success_message; ?>
        </div>
        <?php endif; ?>

        <?php if (!empty($error_message)): ?>
        <div class="bg-red-500 text-white p-2 rounded mb-4 text-center">
            <?php echo $error_message; ?>
        </div>
        <?php endif; ?>

        <form action="registration-of-admin.php" method="POST">
            <div class="mb-4">
                <label for="username" class="block text-gray-700">Username</label>
                <input type="text" name="username" class="w-full p-2 border border-gray-300 rounded mt-1" required>
            </div>
            <div class="mb-4">
                <label for="email" class="block text-gray-700">Email</label>
                <input type="email" name="email" class="w-full p-2 border border-gray-300 rounded mt-1" required>
            </div>
            <div class="mb-4">
                <label for="password" class="block text-gray-700">Password</label>
                <input type="password" name="password" class="w-full p-2 border border-gray-300 rounded mt-1" required>
            </div>
            <button type="submit" class="w-full bg-blue-500 text-white py-2 rounded mt-4 hover:bg-blue-600">Register</button>
        </form>
    </div>
</body>
</html>