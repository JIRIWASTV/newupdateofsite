<?php
$servername = "localhost";  // Replace with your server name or IP
$username = "devicesa_taheemuser";         // Replace with your MySQL username
$password = "UPLTJqVxmAix";             // Replace with your MySQL password
$dbname = "devicesa_taheemnck";  // Replace with your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
