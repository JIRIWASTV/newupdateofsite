<?php 
session_start();

if (!isset($_SESSION['admin_username'])) {
    
    header("Location: index.php");
    exit(); 
}


include $_SERVER['DOCUMENT_ROOT'] . '/seo_data_do_not_modify.php';

include 'db.php'; 

$current_version = 'N/A';

// Fetch current tool version
$result = $conn->query("SELECT tool_version FROM tool_updates WHERE id = 4");
if ($result && $row = $result->fetch_assoc()) {
    $current_version = $row['tool_version'];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Taheem NCK Tool</title>
    
    <link rel="icon" href="/favicon.ico" type="image/x-icon">
    <link rel="shortcut icon" href="/favicon.ico" type="image/x-icon">
    <link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png">
    <link rel="icon" href="/favicon.png" type="image/png">

    <link rel="manifest" href="/site.webmanifest">

    <link rel="stylesheet" href="/./css/tailwind.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
   
    <script src="https://cdn.jsdelivr.net/npm/@sweetalert2/11"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
        .container {
            margin-top: 20px;
        }
        .hidden {
            display: none;
        }
    </style>
</head>
<body class="bg-gray-200 flex">

    <!-- Left Sidebar -->
    <nav class="bg-gray-800 text-white w-1/4 min-h-screen p-4">
        <h2 class="text-xl font-bold mb-4">Admin Options</h2>
        <ul class="space-y-2">
            <li>
                <a href="#" onclick="toggleSection('updateVersionSection')" class="block bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">Update Version</a>
            </li>
            <li>
                <a href="#" onclick="toggleSection1('AddUserSection')" class="block bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">Add User</a>
            </li>
            <li>
                <a href="#" onclick="toggleSection1('AddlicenceSection')" class="block bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">Add Licence</a>
            </li>
            <li>
                <a href="#" onclick="toggleSection1('AddResellerSection')" class="block bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">Add Reseller</a>
            </li>
            <!-- Add other sections as needed -->
        </ul>
    </nav>

    <div class="container mx-auto w-3/4 p-4">
        <header class="bg-gray-900 text-white p-4">
            <div class="flex justify-between items-center">
                <h1 class="text-2xl font-bold">Admin Dashboard</h1>
                <div>
                    <span class="mr-4">Welcome, <?php echo $_SESSION['admin_username']; ?>!</span>
                    <a href="logout.php" class="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600">Logout</a>
                </div>
            </div>
        </header>

        <div class="mt-4">
            <h2 class="text-xl">Current Tool Version: <?php echo $current_version; ?></h2>

            <!-- Update Version Section -->
            <div id="updateVersionSection" class="hidden mt-4">
                <form id="updateVersionForm" method="POST">
                    <div class="mb-4">
                        <label for="tool_version" class="block text-gray-700">Update Tool Version:</label>
                        <input type="text" name="tool_version" class="w-full p-2 border border-gray-300 rounded" placeholder="1.0.2.4" required>
                    </div>
                    <button type="submit" class="bg-blue-500 text-white py-2 px-4 rounded hover:bg-blue-600">Update Version</button>
                </form>
            </div>
            
            <!-- Update Version Section -->
            <div id="AddUserSection" class="hidden mt-4">
                <form id="updateVersionForm" method="POST">
                    <div class="mb-4">
                        <label for="tool_version" class="block text-gray-700">Add User Section:</label>
                        
                    </div>
                    <p>Here will be Add User Section </p>
                </form>
            </div>
            
            <!-- Update Version Section -->
            <div id="AddlicenceSection" class="hidden mt-4">
                <form id="updateVersionForm" method="POST">
                    <div class="mb-4">
                        <label for="tool_version" class="block text-gray-700">Add licence Section:</label>
                        
                    </div>
                    <p>Here will be a Add licence Section too</p>
                </form>
            </div>
            
            <!-- Update Version Section -->
            <div id="AddResellerSection" class="hidden mt-4">
                <form id="updateVersionForm" method="POST">
                    <div class="mb-4">
                        <label for="tool_version" class="block text-gray-700">Add Reseller Section:</label>
                        
                    </div>
                    <p>Here is a Add Reseller Section</p>
                </form>
            </div>
            
        </div>
    </div>
    
    
<script>
    function toggleSection1(sectionId) {
        const sections = ['AddResellerSection', 'AddlicenceSection', 'AddUserSection'];
        sections.forEach(id => {
            const section = document.getElementById(id);
            section.classList.toggle('hidden', id !== sectionId);
        });
    }
</script>

    <script>
        function toggleSection(sectionId) {
            const sections = ['updateVersionSection'];
            sections.forEach(id => {
                const section = document.getElementById(id);
                section.classList.toggle('hidden', id !== sectionId);
            });
        }

        $(document).ready(function() {
            $('#updateVersionForm').on('submit', function(e) {
                e.preventDefault(); // Prevent default form submission

                $.ajax({
                    type: 'POST',
                    url: 'update_version.php',
                    data: $(this).serialize(),
                    success: function(response) {
                        // Parse the JSON response
                        if (typeof response === 'string') {
                            response = JSON.parse(response);
                        }

                        // Display the result using SweetAlert
                        Swal.fire({
                            title: response.message,
                            icon: response.success ? 'success' : 'error',
                            confirmButtonText: 'OK'
                        }).then(() => {
                            if (response.success) {
                                // Reload the page after a successful update
                                setTimeout(() => {
                                    window.location.reload();
                                }, 2000);
                            }
                        });
                    },
                    error: function() {
                        Swal.fire({
                            title: 'An error occurred! Please try again.',
                            icon: 'error',
                            confirmButtonText: 'OK'
                        });
                    }
                });
            });
        });
    </script>
</body>
</html>