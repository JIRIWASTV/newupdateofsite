<?php 
session_start();
include 'db.php'; // Ensure your database connection is included

// Initialize response array
$response = [];

// Check if the tool_version parameter is set in the POST request
if (isset($_POST['tool_version'])) {
    $tool_version = $_POST['tool_version'];

    // Validate the version format
    if (preg_match('/^\d+(\.\d+)*$/', $tool_version)) {
        // Prepare the statement to update tool_version
        $stmt = $conn->prepare("UPDATE tool_updates SET tool_version = ? WHERE id = 4"); // Adjust ID as necessary
        $stmt->bind_param("s", $tool_version); // Use "s" for string type

        // Execute the statement and check for success
        if ($stmt->execute()) {
            $response['success'] = true;
            $response['message'] = "Tool version updated successfully!";
        } else {
            $response['success'] = false;
            $response['message'] = "Error updating tool version: " . $stmt->error;
        }
        $stmt->close(); // Close statement
    } else {
        $response['success'] = false;
        $response['message'] = "Invalid version format. Please use decimal format.";
    }
} else {
    $response['success'] = false;
    $response['message'] = "No version provided.";
}

// Set header to application/json
header('Content-Type: application/json');
echo json_encode($response);
exit();
?>
