function openModal() {
    document.getElementById("confirmation-modal").classList.remove("hidden");
}

function closeModal() {
    document.getElementById("confirmation-modal").classList.add("hidden");
}

function redirect() {
    window.open("https://taheemsoftware.com/", "_blank");
    closeModal();
}