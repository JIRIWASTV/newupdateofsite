function openModal1() {
    document.getElementById("download-unsecured").classList.remove("hidden");
}

function closeModal1() {
    document.getElementById("download-unsecured").classList.add("hidden");
}

function redirect2() {
    window.open("update/Taheem_NCK_Tool.zip", "_blank");
    closeModal1();
}

function redirect1() {
    window.open("https://wa.me/255686695703", "_blank");
    closeModal1();
}