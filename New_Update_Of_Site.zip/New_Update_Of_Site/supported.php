<?php
include $_SERVER['DOCUMENT_ROOT'] . '/seo_data_do_not_modify.php';

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Supported Models - <?php include 'metadata.php'; echo $title2; ?></title>
    <meta name="description" content="<?php echo $description; ?>">
    <meta name="keywords" content="<?php echo $keywords; ?>">
    <meta name="author" content="<?php echo $author; ?>">

    <meta property="og:title" content="<?php echo $og_title; ?>" />
    <meta property="og:description" content="<?php echo $og_description; ?>" />
    <meta property="og:image" content="<?php echo $og_image; ?>" />
    <meta property="og:url" content="<?php echo $og_url; ?>" />
    <meta property="og:type" content="website" />

    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="<?php echo $og_title; ?>">
    <meta name="twitter:description" content="<?php echo $og_description; ?>">
    <meta name="twitter:image" content="<?php echo $og_image; ?>">

    <link rel="icon" href="/favicon.ico" type="image/x-icon">
    <link rel="shortcut icon" href="/favicon.ico" type="image/x-icon">
    <link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png">
    <link rel="icon" href="/favicon.png" type="image/png">

<link rel="manifest" href="/site.webmanifest">

    <script src="css/tailwind.min.css"></script>
    <link rel="stylesheet" href="css/tailwind.min.css">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

<link rel="stylesheet" href="css/styled.css">
<style>
        .whatsapp-icon {
            font-size: 40px; 
            color: #25D366; 
        }
    </style>

    <script>
        function toggleMenu() {
            const menu = document.getElementById("mobile-menu");
            menu.classList.toggle("hidden");
        }
    </script>
</head>
<body class="bg-gray-100 min-h-screen flex flex-col">
    <?php include "default-html/header.html";?>

    <div class="container mx-auto px-4 py-12 flex-grow">
        <h2 class="text-4xl font-semibold text-center mb-6">Supported Models</h2>
        <form class="w-full max-w-auto mx-auto bg-gray-200 p-8 shadow-md rounded">
            <label for="models" class="block text-lg font-medium text-gray-700 mb-2">Supported Models:</label>
            <textarea id="models" name="models" rows="15" class="w-full p-3 border border-gray-300 rounded-md" readonly>
            
            Alcatel Models
- Alcatel 1S (2024)
- Alcatel 1S (2023)
- Alcatel 1B (2023)
- Alcatel 1 (2023)
- Alcatel 1SE (2022)
- Alcatel 3L (2022)
- Alcatel 1L Pro
- Alcatel 1V (2021)
- Alcatel 3L (2021)
- Alcatel 1S (2021)
- Alcatel 5X
- Alcatel 3X (2020)
- Alcatel 1S (2020)
- Alcatel 1SE (2020)
- Alcatel 1V (2020)
- Alcatel 1B (2020)
- Alcatel 1X (2019)
- Alcatel  3L (2019)
- Alcatel 1S (2019)
- Alcatel 1C (2019)
- Alcatel 3V (2019)
- Alcatel 3 (2019)
- Alcatel 1X (2018)
- Alcatel 3L (2018)
- Alcatel 3V (2018)
- Alcatel 3C
- Alcatel 3
- Alcatel 5
- Alcatel 1
- Alcatel A7
- Alcatel A5 LED
- Alcatel IdoI 5
- Alcatel IdoI 4 Pro
- Alcatel Shine Lite
- Alcatel Pop 4

Azumi Models

- Azumi Kilei D
- Azumi L4K
- Azumi V3
- Azumi V4
- Azumi V5
- Azumi IRO A5Q
- Azumi LN2

Acer Models 

- Acer Liquid Z6
- Acer Liquid Z6 Plus
- Acer Liquid Jade S
- Acer Liquid Jade
- Acer Liquid X2
- Acer Liquid X1
- Acer Liquid E700
- Acer Liquid E700 Trio
- Acer Liquid E2
- Acer Liquid Z500
- Acer Liquid Z410
- Acer Liquid Z220
- Acer Liquid Z320
- Acer Liquid Z330
- Acer Liquid Z530
- Acer Liquid Z620S
- Acer Liquid M220
- Acer Liquid E3
- Acer Liquid S2
- Acer Liquid S1
- Acer Liquid Z6s
- Acer Liquid Z6 Plus (2018)
- Acer Liquid Z410 (2018)
- Acer Liquid Z520
- Acer Liquid E2 Duo
- Acer Liquid Z500 (2019)


Chuwi Models

- Chuwi Hi10 X
- Chuwi Hi10 Air
- Chuwi Hi9 Plus
- Chuwi Hi9 Pro
- Chuwi Hi8 Pro
- Chuwi Hi8
- Chuwi Hi10
- Chuwi Hi13
- Chuwi Hi10 Plus
- Chuwi UBook Pro
- Chuwi UBook
- Chuwi SurBook
- Chuwi SurBook Mini
- Chuwi CoreBook Pro
- Chuwi CoreBook


Doogee

- Doogee V Max
- Doogee V
- Doogee S100
- Doogee S98 Pro
- Doogee S98
- Doogee S96 Pro
- Doogee S95
- Doogee S90
- Doogee S80
- Doogee S60
- Doogee S40
- Doogee S30
- Doogee S20
- Doogee S10
- Doogee N40 Pro
- Doogee N40
- Doogee N30
- Doogee N20 Pro
- Doogee N20
- Doogee N10
- Doogee X95
- Doogee X90
- Doogee X70
- Doogee X60
- Doogee X50
- Doogee X30
- Doogee Y9 Plus
- Doogee Y9
- Doogee Y8 Plus
- Doogee Y8
- Doogee Y7
- Doogee Y6
- Doogee Y5
- Doogee Y4
- Doogee Y3
- Doogee Y2
- Doogee Y1
- Doogee Mix 4
- Doogee Mix 3
- Doogee Mix 2
- Doogee Mix
- Doogee F9 Pro
- Doogee F9
- Doogee F8 Pro
- Doogee F8
- Doogee F7
- Doogee F6


Hisense

- Hisense Infinity H40
- Hisense Infinity H30
- Hisense Infinity H20
- Hisense Infinity H10
- Hisense Infinity H9
- Hisense Infinity H8
- Hisense Infinity H7
- Hisense Infinity H6
- Hisense Infinity H5
- Hisense Infinity H4
- Hisense Infinity H3
- Hisense Infinity H2
- Hisense Infinity H1
- Hisense F30
- Hisense F20
- Hisense F10
- Hisense F9
- Hisense F8
- Hisense F7
- Hisense F6
- Hisense F5
- Hisense F4
- Hisense F3
- Hisense F2
- Hisense F1
- Hisense U30
- Hisense U20
- Hisense U10
- Hisense U9
- Hisense U8
- Hisense U7
- Hisense U6
- Hisense U5
- Hisense U4
- Hisense U3
- Hisense U2
- Hisense U1


Huawei

- Huawei P60 Pro
- Huawei P60 
- Huawei P50 Pro
- Huawei P50
- Huawei Mate 50 Pro
- Huawei Mate 50
- Huawei Mate X3
- Huawei Mate X2
- Huawei Mate Xs 2
- Huawei Mate Xs
- Huawei Nova 11 Pro
- Huawei Nova 11
- Huawei Nova 10 Pro
- Huawei Nova 10 
- Huawei Nova 9
- Huawei Nova 8
- Huawei Nova 7
- Huawei Nova 6
- Huawei Y9a
- Huawei Y9s
- Huawei Y9 Prime 2019
- Huawei Y8p
- Huawei Y7a
- Huawei Y7p
- Huawei Y7 Prime 2019
- Huawei Y6p
- Huawei Y6s
- Huawei Y6 Prime 2019
- Huawei Y5p
- Huawei Y5 2019
- Huawei Y4p
- Huawei Y3p
- Huawei Y3 2018
- Huawei P Smart 2021
- Huawei P Smart 2022
- Huawei P Smart Pro
- Huawei P Smart Z
- Huawei Enjoy 20 Pro
- Huawei Enjoy 20
- Huawei Enjoy 10 Plus
- Huawei Enjoy 10
- Huawei Honor 30 Pro+
- Huawei Honor 30 Pro
- Huawei Honor 30
- Huawei Honor 20 Pro
- Huawei Honor 20


Infinix

- Infinix Zero Ultra
- Infinix Zero 30 5G
- Infinix Zero 20
- Infinix Zero X Pro
- Infinix Zero X
- Infinix Zero 8
- Infinix Zero 8i
- Infinix Note 30
- Infinix Note 30 Pro
- Infinix Note 12 Turbo
- Infinix Note 12
- Infinix Note 11
- Infinix Note 11 Pro
- Infinix Note 10
- Infinix Note 10 Pro
- Infinix Hot 30
- Infinix Hot 30 Pro
- Infinix Hot 20
- Infinix Hot 20 Pro
- Infinix Hot 11s
- Infinix Hot 11
- Infinix Hot 10S
- Infinix Hot 10
- Infinix Hot 9 Pro
- Infinix Hot 9
- Infinix Smart 7
- Infinix Smart 6 Plus
- Infinix Smart 6
- Infinix Smart 5
- Infinix Smart 5A
- Infinix S6
- Infinix S5 Pro
- Infinix S5
- Infinix S4
- Infinix S3X
- Infinix S3
- Infinix X551
- Infinix X600
- Infinix X551 Plus
- Infinix X604
- Infinix X506
- Infinix X501
- Infinix X555
- Infinix X603
- Infinix X507


Itel

- Itel S23 Pro
- Itel S23
- Itel P40
- Itel P40 Pro
- Itel A60
- Itel A60 Pro
- Itel Vision 3 Plus
- Itel Vision 3
- Itel Vision 2
- Itel Vision 2 Pro
- Itel P38
- Itel P38 Pro
- Itel P37
- Itel P37 Pro
- Itel P36
- Itel P36 Pro
- Itel A58
- Itel A58 Pro
- Itel A57
- Itel A56
- Itel A55
- Itel A54
- Itel A53
- Itel A52
- Itel A51
- Itel A50
- Itel A49
- Itel A48
- Itel A47
- Itel A46
- Itel A45
- Itel A44
- Itel A43
- Itel A42
- Itel A41
- Itel A40
- Itel A39
- Itel A38
- Itel A37
- Itel A36
- Itel A35
- Itel A34
- Itel A33
- Itel A32
- Itel A31
- Itel A30
- Itel A29


Mobicel

- Mobicel Aqua
- Mobicel Pulse
- Mobicel Zest
- Mobicel Comet
- Mobicel Titan
- Mobicel Vibe
- Mobicel Stellar
- Mobicel X
- Mobicel Max
- Mobicel Jive
- Mobicel Blink
- Mobicel V10
- Mobicel V20
- Mobicel M10
- Mobicel M20
- Mobicel M30
- Mobicel F5
- Mobicel F6
- Mobicel F7
- Mobicel F8
- Mobicel F9
- Mobicel C5
- Mobicel C6
- Mobicel C7
- Mobicel C8
- Mobicel C9


Nokia

- Nokia G22
- Nokia G21
- Nokia G20
- Nokia G11 Plus
- Nokia G11
- Nokia X30
- Nokia X20
- Nokia X10
- Nokia C32
- Nokia C31
- Nokia C30
- Nokia C21 Plus
- Nokia C21
- Nokia C12
- Nokia C10
- Nokia C2 2nd Edition
- Nokia C2
- Nokia C1 2nd Edition
- Nokia C1 Plus
- Nokia C1
- Nokia 8.3 5G
- Nokia 8.1
- Nokia 7.2
- Nokia 6.2
- Nokia 5.4
- Nokia 5.3
- Nokia 5.2
- Nokia 4.2
- Nokia 3.4
- Nokia 3.2
- Nokia 2.4
- Nokia 2.3
- Nokia 2.2
- Nokia 1.4
- Nokia 1.3
- Nokia 1.2
- Nokia 1.1
- Nokia 9 PureView
- Nokia 8.1 Plus
- Nokia 8 Sirocco
- Nokia 7.1
- Nokia 6.1 Plus
- Nokia 5.1 Plus
- Nokia 3.1 Plus
- Nokia 2.1
- Nokia 1 Plus
- Nokia XR20
- Nokia X71
- Nokia 2720 Flip
- Nokia 8110 4G
- Nokia 3310 4G
- Nokia 6300 4G
- Nokia 800 Tough
- Nokia 110 4G
- Nokia 105 4G
- Nokia 225 4G
- Nokia 215 4G


Oppo

- Oppo Find X6 Pro
- Oppo Find X6
- Oppo Reno 9 Pro
- Oppo Reno 9
- Oppo Reno 8 Pro
- Oppo Reno 8
- Oppo Reno 8 Lite
- Oppo A78 5G
- Oppo A77 5G
- Oppo A76
- Oppo A75
- Oppo A74 5G
- Oppo A74
- Oppo A73
- Oppo A72
- Oppo A55s 5G
- Oppo A55
- Oppo A54
- Oppo A53s 5G
- Oppo A53
- Oppo A52
- Oppo A31
- Oppo A30
- Oppo F23 Pro
- Oppo F23
- Oppo F21 Pro
- Oppo F21
- Oppo F19 Pro
- Oppo F19
- Oppo F17 Pro
- Oppo F17
- Oppo F15
- Oppo F11 Pro
- Oppo F11
- Oppo F11 Marvel Edition
- Oppo F11 Pro 8GB
- Oppo F11 Pro 6GB
- Oppo F11 4GB
- Oppo F9 Pro
- Oppo F9
- Oppo F7
- Oppo F5
- Oppo F3 Plus
- Oppo F3
- Oppo F1 Plus
- Oppo F1
- Oppo A39
- Oppo A37


Samsung

- Galaxy S23 Ultra
- Galaxy S23+
- Galaxy S23
- Galaxy S22 Ultra
- Galaxy S22+
- Galaxy S22
- Galaxy S21 Ultra
- Galaxy S21+
- Galaxy S21
- Galaxy S21 FE
- Galaxy S20 Ultra
- Galaxy S20+
- Galaxy S20
- Galaxy S20 FE
- Galaxy Note 20 Ultra
- Galaxy Note 20
- Galaxy Z Fold 5
- Galaxy Z Fold 4
- Galaxy Z Fold 3
- Galaxy Z Fold 2
- Galaxy Z Flip 5
- Galaxy Z Flip 4
- Galaxy Z Flip 3
- Galaxy Z Flip
- Galaxy A73
- Galaxy A72
- Galaxy A71
- Galaxy A53
- Galaxy A52
- Galaxy A51
- Galaxy A33
- Galaxy A32
- Galaxy A31
- Galaxy A23
- Galaxy A22
- Galaxy A21s
- Galaxy A21
- Galaxy A13
- Galaxy A12
- Galaxy A11
- Galaxy A04
- Galaxy A03s
- Galaxy A03
- Galaxy M53
- Galaxy M52
- Galaxy M51
- Galaxy M33
- Galaxy M32
- Galaxy M31
- Galaxy M23
- Galaxy M22
- Galaxy M21
- Galaxy M13
- Galaxy M12
- Galaxy M11
- Galaxy F62
- Galaxy F52
- Galaxy F41
- Galaxy F23
- Galaxy F22
- Galaxy F12
- Galaxy F02s
- Galaxy XCover 6 Pro
- Galaxy XCover 5
- Galaxy Tab S8 Ultra
- Galaxy Tab S8+
- Galaxy Tab S8
- Galaxy Tab S7+
- Galaxy Tab S7
- Galaxy Tab S7 FE
- Galaxy Tab A8
- Galaxy Tab A7 Lite
- Galaxy Tab A7
- Galaxy Tab A 10.1
- Galaxy Tab A 8.4
- Galaxy Tab Active 3
- Galaxy Tab Active Pro
- Galaxy Fold
- Galaxy Flip
- Galaxy W22
- Galaxy Quantum 2
- Galaxy Quantum
- Galaxy M02
- Galaxy M02s
- Galaxy A02
- Galaxy A02s
- Galaxy J2 Core 2020
- Galaxy J7 Prime 2
- Galaxy J4+
- Galaxy J2 Pro 2018
- Galaxy A01
- Galaxy A01 Core
- Galaxy A10
- Galaxy A10s
- Galaxy A20
- Galaxy A20s


Smart Kitoch (KaiOS)

- Smart Kitoch Alpha
- Smart Kitoch Beta
- Smart Kitoch Gamma
- Smart Kitoch Delta
- Smart Kitoch Epsilon
- Smart Kitoch Zeta
- Smart Kitoch Eta
- Smart Kitoch Theta
- Smart Kitoch Iota
- Smart Kitoch Kappa
- Smart Kitoch Lambda
- Smart Kitoch Mu
- Smart Kitoch Nu
- Smart Kitoch Xi


Tecno

- Spark 10 Pro
- Spark 10
- Camon 20 Pro
- Camon 20
- Pova 5
- Pova 5 Pro
- Phantom V
- Phantom X2
- Camon 19 Pro
- Camon 19
- Pop 7
- Pop 7 Pro
- Pouvoir 4
- Pouvoir 4 Pro
- Spark 9 Pro
- Spark 9
- Phantom X
- Phantom 9
- Pova 4
- Pova 4 Pro
- Camon 18 Premier
- Camon 18
- Pop 6
- Pop 6 Pro
- Pouvoir 3 Plus
- Pouvoir 3
- Spark 8 Pro
- Spark 8
- Camon 17 Pro
- Camon 17
- Pop 5
- Pop 5 Pro
- Pova 3
- Pova 3 Pro
- Camon 16 Premier
- Camon 16
- Spark 7 Pro
- Spark 7 
- Pouvior 2 Plus
- Pouvior 2
- Phantom 8
- Camon CX Air
- Camon CX
- Camon C9
- Camon C8
- L8
- L9 Plus
- L9
- W5
- W4
- Spark 11 Pro
- Spark 11
- Camon 21 Pro
- Camon 21
- Pova 6
- Pova 6 Pro
- Phantom V Flip
- Phantom X3
- Camon 20 Lite
- Camon 20 Premier
- Pop 8
- Pop 8 Pro
- Pouvoir 5
- Pouvoir 5 Pro
- Spark 12
- Spark 12 Pro


Xiaomi

- Xiaomi Mi 13 Ultra
- Xiaomi Mi 13 Pro
- Xiaomi Mi 13 
- Xiaomi Mi 12T Pro
- Xiaomi Mi 12T
- Xiaomi Mi 12 Lite
- Xiaomi Mi 11 Ultra
- Xiaomi Mi 11 Pro
- Xiaomi Mi 11
- Xiaomi Mi 10 Ultra
- Xiaomi Mi 10 Pro
- Xiaomi Mi 10
- Xiaomi Mi 9 Pro
- Xiaomi Mi 9
- Xiaomi Mi 8 Pro
- Xiaomi Mi 8
- Xiaomi Mi 7
- Xiaomi Mi 6
- Xiaomi Mi Mix 4
- Xiaomi Mi Mix 3
- Xiaomi Mi Mix 2S
- Xiaomi Mi Mix 2
- Xiaomi Mi Mix 1
- Xiaomi Redmi Note 13 Pro
- Xiaomi Redmi Note 13
- Xiaomi Redmi Note 12 Pro
- Xiaomi Redmi Note 12
- Xiaomi Redmi Note 11 Pro
- Xiaomi Redmi Note 11
- Xiaomi Redmi Note 10 Pro
- Xiaomi Redmi Note 10
- Xiaomi Redmi Note 9 Pro
- Xiaomi Redmi Note 9
- Xiaomi Redmi Note 8 Pro
- Xiaomi Redmi Note 8 
- Xiaomi Redmi 11 Prime
- Xiaomi Redmi 10 Prime
- Xiaomi Redmi 10
- Xiaomi Redmi 9T
- Xiaomi Redmi 9
- Xiaomi Redmi 8A
- Xiaomi Redmi 8
- Xiaomi Redmi 7A
- Xiaomi Redmi 7
- Xiaomi Poco F5 Pro
- Xiaomi Poco F5
- Xiaomi Poco X5 Pro
- Xiaomi Poco X5
- Xiaomi Poco M4 Pro
- Xiaomi Poco M4
- Xiaomi Poco X4 Pro
- Xiaomi Poco X4
- Xiaomi Poco M3 Pro
- Xiaomi Poco M3
- Xiaomi Poco F3
- Xiaomi Poco X3 Pro
- Xiaomi Poco X3
- Xiaomi Poco M2 Pro
- Xiaomi Poco M2
- Xiaomi Mi A3
- Xiaomi Mi A2
- Xiaomi Mi A1
            </textarea>
        </form>
    </div>

    <?php include "default-html/footer.html";?>
</body>
</html>
