<?php
include $_SERVER['DOCUMENT_ROOT'] . '/seo_data_do_not_modify.php';

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php include 'metadata.php'; echo $title; ?></title>
    <meta name="description" content="<?php echo $description; ?>">
    <meta name="keywords" content="<?php echo $keywords; ?>">
    <meta name="author" content="<?php echo $author; ?>">

    <meta property="og:title" content="<?php echo $og_title; ?>" />
    <meta property="og:description" content="<?php echo $og_description; ?>" />
    <meta property="og:image" content="<?php echo $og_image; ?>" />
    <meta property="og:url" content="<?php echo $og_url; ?>" />
    <meta property="og:type" content="website" />

    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="<?php echo $og_title; ?>">
    <meta name="twitter:description" content="<?php echo $og_description; ?>">
    <meta name="twitter:image" content="<?php echo $og_image; ?>">

    <link rel="icon" href="/favicon.ico" type="image/x-icon">
    <link rel="shortcut icon" href="/favicon.ico" type="image/x-icon">
    <link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png">
    <link rel="icon" href="/favicon.png" type="image/png">

    <link rel="manifest" href="/site.webmanifest">

    <link rel="stylesheet" href="css/tailwind.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="css/styled.css">

    <style>
        .whatsapp-icon {
            font-size: 40px; 
            color: #25D366; 
        }
    </style>

    <script>
        function toggleMenu() {
            const menu = document.getElementById("mobile-menu");
            menu.classList.toggle("hidden");
        }
    </script>
</head>
<body class="bg-gray-100">

    <?php include "default-html/header.html";?>

    <section class="container mx-auto px-6 py-12 flex flex-col md:flex-row items-center">
        <div class="md:w-1/2">
            <img src="images/Taheem_Tool.png" alt="Image" class="rounded-lg shadow-lg">
        </div>
        <div class="md:w-1/2 flex flex-col space-y-8 mt-8 md:mt-0 md:ml-12">
            <?php include "default-html/card-1.html";?>
            <?php include "default-html/card-2.html";?>
        </div>
    </section>

    <!-- Download Unsecured Modal -->
    <div id="download-unsecured" class="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 hidden">
        <div class="bg-white p-6 rounded-lg shadow-lg w-full md:w-2/3 lg:w-1/2">
            <h3 class="text-lg font-bold mb-4">
                <i class="fas fa-download"></i> Download
            </h3>
            <hr>
            <br><br>
            <p class="text-base md:text-xl font-bold">Downloading the exe will require an active and valid license of use.</p>
            <p class="text-sm md:text-base">File is protected, and only users with a valid license will have access.</p>
            
            <br>
            <p class="text-sm md:text-base">To get the password, contact admin(s) below.</p>
            <br>
            <hr>
            <div class="flex justify-end mt-6 space-x-4">
                <button class="px-4 py-2 bg-red-500 text-white hover:bg-red-800 rounded-lg text-sm md:text-base" onclick="closeModal1()">Cancel</button>
                <button class="px-4 py-2 bg-green-700 text-white hover:bg-green-800 rounded-lg text-sm md:text-base" onclick="redirect1()">
                    <i class="fab fa-whatsapp"></i> Get Password
                </button>
                <button class="px-4 py-2 bg-green-700 text-white hover:bg-green-800 rounded-lg text-sm md:text-base" onclick="redirect2()">
                    <i class="fas fa-download"></i> Download Taheem NCK Tool Latest
                </button>
            </div>
        </div>
    </div>

    <!-- Confirmation Modal -->
    <div id="confirmation-modal" class="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 hidden">
        <div class="bg-white p-6 rounded-lg shadow-lg w-full md:w-2/3 lg:w-1/2">
            <h3 class="text-lg font-bold mb-4">
                <i class="fas fa-server"></i> Proceed to third party
            </h3>
            <hr><br><br>
            <p class="text-base md:text-xl font-bold">Now you're going to visit our server website.</p>
            <p class="text-sm md:text-base">Where you can directly activate Taheem NCK Tool and access many online services.</p>
            <br><br>
            <hr>
            <div class="flex justify-end mt-6 space-x-4">
                <button class="px-4 py-2 bg-red-500 text-white hover:bg-red-800 rounded-lg text-sm md:text-base" onclick="closeModal()">Cancel</button>
                <button class="px-4 py-2 bg-green-700 text-white hover:bg-green-800 rounded-lg text-sm md:text-base" onclick="redirect()">Open in New Window</button>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <?php include "default-html/footer.html";?>

    <!-- JQuery Start -->
    <script src="js/tsdload.js"></script>
    <script src="js/taheem.js"></script>
    <!-- JQuery End -->

</body>
</html>
